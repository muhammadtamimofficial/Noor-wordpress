<?php defined( 'ABSPATH' ) or die( "No script kiddies please!" ); ?>
<img style="width:100%;" src="<?php echo WP1S_IMG_DIR . '/demo/upgrade-to-pro.png' ?>"/>
<div class="wp1s-button-wrap-backend">
    <a class="wp1s-pro-demo" href="http://demo.accesspressthemes.com/wordpress-plugins/wp-1-slider-pro" target="_blank"><?php _e( 'Demo', 'wp-1-slider' ); ?></a>
    <a class="wp1s-pro-demo" href="https://accesspressthemes.com/wordpress-plugins/wp1-slider-pro/" target="_blank"><?php _e( 'Upgrade', 'wp-1-slider' ); ?></a>
    <a class="wp1s-pro-demo" href="https://accesspressthemes.com/wordpress-plugins/wp1-slider-pro/" target="_blank"><?php _e( 'Plugin Information', 'wp-1-slider' ); ?></a>
</div>
<img style="width:100%;" src="<?php echo WP1S_IMG_DIR . '/demo/upgrade-to-pro-feature.png' ?>"/>
