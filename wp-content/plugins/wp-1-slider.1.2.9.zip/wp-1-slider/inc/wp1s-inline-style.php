<style>

.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> {
    
     width:<?php echo esc_attr($wp1s_slide_width);?>%;   
}

.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-1 .wp1s-caption-title{

    font-size:<?php echo esc_attr($wp1s_title_1_font_size);?>px;
   
}

.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-1 .wp1s-caption-content{
   
    font-size: <?php echo esc_attr($wp1s_description_1_font_size);?>px;
    
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-2 .wp1s-caption-title {
    font-size:<?php echo esc_attr($wp1s_title_1_font_size);?>px;
    background-color:<?php echo esc_attr($wp1s_title_back_color);?>;
   
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-2 .wp1s-caption-content {
    font-size:<?php echo esc_attr($wp1s_description_1_font_size);?>px;

}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-3 .wp1s-caption-title {
    font-size:<?php echo esc_attr($wp1s_title_1_font_size);?>px;
    border-bottom:7px solid <?php echo esc_attr($wp1s_caption_border_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-3 .wp1s-caption-content {
    font-size:<?php echo esc_attr($wp1s_description_1_font_size);?>px;
   
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-4  {
   
    background-color:<?php echo esc_attr($wp1s_caption_back_color); ?>;

}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-4 .wp1s-caption-title {
    font-size:<?php echo esc_attr($wp1s_title_1_font_size);?>px;

}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-4 .wp1s-caption-content {
    font-size:<?php echo esc_attr($wp1s_description_1_font_size);?>px;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper .wp1s-caption-title {
    color:<?php echo esc_attr($wp1s_title_text_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper .wp1s-caption-content {
    color:<?php echo esc_attr($wp1s_description_text_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-1 .bx-wrapper .bx-pager.bx-default-pager a {
    background-color:<?php echo esc_attr($wp1s_dot_back_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-1 .bx-wrapper .bx-pager.bx-default-pager a:hover, 
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-1 .bx-wrapper .bx-pager.bx-default-pager a.active {
    background-color:<?php echo esc_attr($wp1s_dot_hover_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-2 .bx-wrapper .bx-pager.bx-default-pager a {
    background-color:<?php echo esc_attr($wp1s_dot_2_back_color); ?>;
    border:3px solid <?php echo esc_attr($wp1s_dot_2_border_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-2 .bx-wrapper .bx-pager.bx-default-pager a:hover, 
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-2 .bx-wrapper .bx-pager.bx-default-pager a.active {
    background-color:<?php echo esc_attr($wp1s_dot_2_active_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-3 .bx-wrapper .bx-pager.bx-default-pager a {
    border:1px solid <?php echo esc_attr($wp1s_dot_3_border_color); ?>;
   
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-3 .bx-wrapper .bx-pager.bx-default-pager a:hover, 
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-3 .bx-wrapper .bx-pager.bx-default-pager a.active {
    border-color:<?php echo esc_attr($wp1s_dot_3_active_color); ?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-4 .bx-wrapper .bx-pager.bx-default-pager a {
    background-color:<?php echo esc_attr($wp1s_dot_4_back_color);?>;
    
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-4 .bx-wrapper .bx-pager.bx-default-pager a:hover, 
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-main-wrapper .wp1s-pager-type-4 .bx-wrapper .bx-pager.bx-default-pager a.active {
    background-color:<?php echo esc_attr($wp1s_dot_4_active_color);?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-1 .wps1-readmore-button {
    background-color: <?php echo esc_attr($wp1s_button_color); ?>;
    box-shadow: 0 2px 0 <?php echo esc_attr($wp1s_button_shadow_color);?>;
    -webkit-box-shadow: 0 2px 0 <?php echo esc_attr($wp1s_button_shadow_color);?>;
    -moz-box-shadow: 0 2px 0 <?php echo esc_attr($wp1s_button_shadow_color);?>;
}
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-caption-wrapper.wp1s-caption-type-1 .wps1-readmore-button:hover {
    background-color:<?php echo esc_attr($wp1s_button_hover_color); ?>;
}
@media (max-width:1200px) {
.wp1s-slider-wrapper-<?php echo esc_attr($random_num); ?> .wp1s-slider-wrapper {
width:100%;
}
}
.wp1s-widget-wrap .wp1s-caption-wrapper {

display: <?php if($wp1s_show_caption_widget==1){ echo "block"; } else { echo "none"; }?>;
}

.wp1s-widget-wrap .wp1s-thumbnail-wrapper {
display: <?php if($wp1s_show_thumb_widget==1){ echo "block"; } else { echo "none"; }?>;
}

</style>